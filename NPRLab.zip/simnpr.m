function [Yt, L, h, varargout] = simnpr(model,Xt,varargin)
%   Simulate non-parametric regressor model
%
%   Author: Pieter Jan Kerstens, 2012
%
%   [Yt, L, h] = SIMNPR(model,Xt)
%       model: model structure created by initnpr
%       Xt: test data
%
%       Yt: simulated output of the model
%       L: smoother matrix
%       h: bandwidth of the kernel
%
%   See also: initnpr, cinpr
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    if(strcmpi(model.smoothername(1:2),'ls')) % LS-SVM
        if(nargout >= 2) % avoid doing double work by computing Yt using the L matrix!
            L = smootherlssvmmod(model,Xt,varargin{:});
            h = model.kernel_pars;
            
            Yt = L*model.ytrain;
            
            % postprocessing...
            if model.preprocess(1)=='p'
                [~,Yt] = postlssvm(model,[],Yt);
            end
        else % more efficient than L*Y!
            Yt = simlssvm(model,Xt);
        end
        
    else % Nadaraya-Watson, local polynomial, Priestley-Chao
        % preprocess the test data
        if model.preprocess(1)=='p',
            [Xt,~] = prelssvm(model,Xt,[]);
        end
        
        varargout = cell(1,nargout-3);
        [Yt,L,h,varargout{:}] = model.smoother(Xt);
        
        % postprocess the simulated output
        if model.preprocess(1)=='p'
            [~,Yt] = postlssvm(model,[],Yt);
        end    
    end
end