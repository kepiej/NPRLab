function model = initnpr(X,Y,type,preprocess,h,varargin)
%   Initialize and train non-parametric regressor model
%
%   Author: Pieter Jan Kerstens, 2012
%
%   model = INITNPR(X,Y,type,preprocess,h,varargin)
%       X,Y: model data with dim(X) = [n x d] and dim(Y) = [n x 1]
%       type: type of smoother. Type can be 'nadaraya-watson', 'local polynomial', 'priestley-chao' or 'ls-svm'.
%       preprocess: (optional, default = 'preprocess') preprocess the data
%       h: (optional, default = leave-one-out cross-validation) bandwidth of the kernel
%       varargin: contains additional options to pass to the smoother. This
%       can be a function handle to a kernel. It's smoother dependent.
%
%       model: model structure
%
%   See also: simnpr, cinpr
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    if((nargin < 4) || isempty(preprocess))
        preprocess = 'preprocess';
    end
    model.preprocess = preprocess;    
    
    
    % If 1D then sort X in ascending order
    if(size(X,2) == 1)
        [X,sind] = sort(X);
        Y = Y(sind);
    end
    
    if(strcmpi(type(1:2),'ls')) % LS-SVM
        if(isempty(varargin))
            kernelname = 'RBF_kernel';
        else
            kernelname = varargin{1};
        end
        
        if(nargin < 5 || isempty(h))
            % Tune the hyperparameters
            model = initlssvm(X,Y,'f',[],[],kernelname,model.preprocess);
            model = tunelssvm(model,'simplex','crossvalidatelssvm',{10,'mse'});
        else
            model = initlssvm(X,Y,'f',h{1},h{2},kernelname,model.preprocess);
        end
        
        model = trainlssvm(model);
        model.smoothername = 'ls-svm';
        
        % Precompute some stuff that we'll need often
        % This results in a significant speed-up in the voltube.m computations
        K = kernel_matrix(model.xtrain,model.kernel_type,model.kernel_pars);
        Z = pinv(K+eye(model.nb_data)./model.gam);
        c = sum(sum(Z));
        J = ones(model.nb_data)./c;
        
        model.smoother = @(x) simnpr(model,x,K,Z,c,J);
    else % Nadaraya-Watson, local polynomial regression, Priestley-Chao
        names = containers.Map({'na', 'lo', 'pr'},{{@nw,'nadaraya-watson'}, {@localpolyfit,'local polynomial'},{@priestleychao,'priestley-chao'}});
		smnamelist = 'Nadaraya-Watson (na), LS-SVM (ls), Local polynomial regression (lo), Priestley-Chao (pr)';
        % Add custom linear smoothers
        smlist = ls('NPRLab\addins');
        for j=3:size(smlist,1)
            names(smlist(j,1:2)) = {str2func(smlist(j,1:end-2)),smlist(j,1:end-2)};
            smnamelist = [smnamelist,', ',smlist(j,1:end-2),' (',smlist(j,1:2),')'];
        end
        
        try
            smhandle = names(lower(type(1:2)));
        catch
            error('Unknown type of smoother! Choose one of these: %s',smnamelist);
        end
        
        model.smoothername = smhandle{2};
        smhandle = smhandle{1};
        model.type = 'f';
        
        model.xtrain = X;
        model.ytrain = Y(:);
        model.x_dim = size(X,2);
        model.y_dim = size(Y,2);
        model.nb_data = size(X,1);
    
        if model.preprocess(1) == 'p', 
            model.prestatus='changed';
        else
            model.prestatus='ok'; 
        end
        
        % Make zero mean and unit variance
        model = prelssvm(model);
        
        model.status = 'changed';
        
        % Convert kernel name to function handle
        if(~isempty(varargin))
            varargin{1} = str2func(varargin{1});
        end
        
        if(nargin < 5 || isempty(h))
            % Tune the bandwidth parameter using leave-one-out cross-validation  
            h = linearbandwidthtuning(model.ytrain,@(x) smhandle(model.xtrain,model.ytrain,model.xtrain,x,varargin{:}));
        end
        model.kernel_pars = h;
        
        model.smoother = @(x) smhandle(model.xtrain,model.ytrain,x,model.kernel_pars,varargin{:});
        
        model.status = 'trained';
    end
    
    if(~isempty(varargin))
        model.extrarg = varargin;
    else
        model.extrarg = [];
    end
end