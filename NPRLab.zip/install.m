% Check if LS-SVMlab is installed
if(exist('initlssvm','file')~= 2||exist('tunelssvm','file')~= 2||exist('trainlssvm','file')~= 2)
    disp('LS-SVMlab is not installed or not added to the MATLAB path!');
    lssvmpath = uigetdir('','Please select the folder containing the LS-SVMlab toolbox');
    if(lssvmpath ~= 0)
        addpath(lssvmpath);
    end
    if((exist('initlssvm','file') ~= 2) | (lssvmpath == 0))
       error('The NPRLab toolbox requires LS-SVMLab to run properly. Please download LS-SVMlab from <a href="http://www.esat.kuleuven.be/sista/lssvmlab/">http://www.esat.kuleuven.be/sista/lssvmlab/</a> and run this installer again.');
    end
    clear lssvmpath;
end

curpath = cd;
ind = strfind(curpath,'\NPRLab');
if(~isempty(ind))
    curpath = curpath(1:ind-1);
end

addpath([curpath, '\NPRLab']);
addpath([curpath, '\NPRLab\addins']);
addpath([curpath, '\NPRLab\datasets']);
addpath([curpath, '\NPRLab\examples']);

disp('NPRLab is ready for use!');

clear curpath ind;