function updatenpr()
%   Check for updates of the NPRLab toolbox
%
%   Author: Pieter Jan Kerstens, 2015
%
%   UPDATENPR()
%
%   See also: vernpr
%
%   Copyright (C) 2015, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)

    curvers = vernpr();
    fprintf('You have NPRLab %s\n',curvers);
    disp('Checking for updates of NPRLab...');
    [latestverstr,status] = urlread('http://kerstens.hopto.org/nprlab/currentversion');
    if(status == 1)
        latestvers = cell2mat(strsplit(latestverstr,'.'));
        curvers = cell2mat(strsplit(curvers,'.'));
        
        isupdate = 0;
        for k=1:length(latestvers)
            if(latestvers(k) > curvers(k))
                isupdate = 1;
                break;
            end
        end
        
        if(isupdate)
            fprintf('Update available! Latest version is %s. Download it from <a href="http://kerstens.hopto.org/nprlab">http://kerstens.hopto.org/nprlab</a>!\n',latestverstr);
        else
            disp('You already have the latest version!');
        end
    else
        disp('Checking for updates of NPRLab failed! Please check your network connection and try again.');
    end
end

