% The data points and optionally the number of data points
n = 100;
X = linspace(0,1,n)';
% Model that generates the Y
TrueFtName = '';
TrueFt = sin(2*pi*(X-0.5)).^2;
% Noise model
sig = 0.3;
Noise = sig.*randn(n,1);
% Confidence level
alpha = 0.05;
% Simultaneous confidence band method: Bonferroni (0) or Sidak (1)
simul = 1;