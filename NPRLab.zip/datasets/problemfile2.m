% The data points and optionally the number of data points
n = 100;
X = linspace(0,1,n)';
% Model that generates the Y
TrueFtName = '';
TrueFt = (6/10).*betalm(30,17,X) + (4/10).*betalm(3,11,X);
% Noise model
sig = 0.1;
Noise = sig.*randn(n,1);
% Confidence level
alpha = 0.05;
% Simultaneous confidence band method: Bonferroni (0) or Sidak (1)
simul = 1;