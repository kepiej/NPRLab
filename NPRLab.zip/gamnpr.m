function [newY,Li,h] = gamnpr(X,Y,type,opt,varargin)
%   Fit an additive model using the (simple) backfitting algorithm
%   See Buja et al. (1989) for more information.
%
%   Implementation as described in H�rdle, "Nonparametric and Semiparametric Models" chapter 8
%
%   Author: Pieter Jan Kerstens, 2012
%
%   [newY, L, h] = GAMNPR(X,Y,type,opt,varargin)
%       X,Y: model data
%       type: type of smoother (choose from: 'na','lo' or 'ls'). This can
%       be a cell containing different smoothers for each dimension.
%       opt: (optional) optimization options that can contain:
%           Tol: minimum change between iterations (default = sqrt(eps)).
%           MaxIter: maximum number of iterations (defaul = 60).
%       varargin: optional parameters which are passed to the smoother (see
%       smoother help for more info)
%
%       newY: model evaluation at X
%       Li: cell that contains the smoother matrices of all models.
%       smoother matrix.
%       h: cell that contains the used bandwith of all models.
%
%   See also INITNPR, NW, LOCALPOLYFIT
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    n = size(X,1);
    d = size(X,2);
    models = cell(1,d);
    f = zeros(n,d);
    Li = cell(1,d);
    h = zeros(1,d);
    
    if(d <= 1)
        error('gamnpr:MinDim','Dimension should be >= 2. Current dimension is %i',d);
    end
    
    alpha = mean(Y);
        
    if(iscell(type))
        if(size(type,2) < d)
            oldtype = type;
            type{1:size(oldtype,2)} = oldtype{:};
            for k=size(oldtype,2)+1:d
                type{k} = oldtype{size(oldtype,2)};
            end
        end
    else % Use the same model for each dimension
        oldtype = type;
        type = cell(1,d);
        for k=1:d
            type{k} = oldtype;
        end
    end
    
    % Options processing
    defopt = {sqrt(eps),60};
    if((nargin > 3) && ~isempty(opt))
        defopt{1:length(opt)} = opt{:};
    end
    [Tol,MaxIter] = defopt{:};
    
    iter = 0;
    maxchange = inf;
    sumf = zeros(n,1);
    ind = ones(1,d);
    Licorr = eye(n) - (ones(n)./n);
    while((maxchange >= Tol) && (iter < MaxIter))
        maxchange = 0;
        iter = iter + 1;
        fold = f;
                        
        for j=1:d
            ind(j) = 0;
            sumf = alpha + sum(f(:,ind > 0),2);
            ind(j) = 1;
            
            Yt = Y - sumf;
            
            models{j} = initnpr(X(:,j),Yt,type{j},varargin{:});
            [f(:,j),Li{j},h(j)] = simnpr(models{j},X(:,j));
            
            % Normal backfitting
            f(:,j) = f(:,j) - mean(f(:,j));
            Li{j} = Licorr*Li{j};
            
            iterchange = norm(f(:,j)-fold(:,j),Inf);
            if(iterchange > maxchange)
                maxchange = iterchange;
            end
        end
    end
    
    if(iter == MaxIter)
        warning('gamnpr:MaxIter','Maximum number of iterations reached. MaxChange is %g. Increase number of iterations to reach convergence.',maxchange);
    end
    
    newY = sumf;
end