function plotnpr(model,varargin)
%   Plot the model along with the training data and optionally draw
%   confidence bands and the true function
%
%   Author: Pieter Jan Kerstens, 2012
%
%   PLOTNPR(model,varargin)
%       model: the model structure obtained from initnpr
%       varargin can contain:
%           ci: n x 2 matrix containing the upper and lower confidence bands
%           Ytrue: a n x 1 vector containg the true function values
%           seldims: matrix containing the dimensions of X to draw
%
%   See also: initnpr, cinpr
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    if(length(varargin) > 3)
        error('plotnpr:TooManyInputs','requires at most 3 optional inputs');
    end
    
    optargs = cell(1,3); % Set default variable arguments
    optargs(1:length(varargin)) = varargin; % Replace by optionally provided arguments
    [ci,Ytrue,seldims] = optargs{:};
    
    if model.preprocess(1)=='p'
        [x,y] = postlssvm(model,model.xtrain,model.ytrain);
    else
        x = model.xtrain; y = model.ytrain;
    end

    Yt = simnpr(model,x);
    
    hold on;
    if((model.x_dim == 1) || (length(seldims) == 1))
        if(isempty(seldims))
            seldims = 1;
        end
        plot(x(:,seldims),Yt,'r-','LineWidth',2);
        hold on;
        plot(x(:,seldims),y,'b.','LineWidth',2);
        if(~isempty(ci))
            plot(x(:,seldims),ci(:,1),'black-','LineWidth',2);
            plot(x(:,seldims),ci(:,2),'black-','LineWidth',2);
        end
        if(~isempty(Ytrue))
            plot(x(:,seldims),Ytrue,'g-','LineWidth',2);
        end
        xlabel(sprintf('X_%i',seldims),'FontSize',12);
        ylabel('Y','FontSize',12);
        hold off;
    elseif((model.x_dim == 2) || ~isempty(seldims))
        if(isempty(seldims))
            seldims = [1 2];
        end
        plot3(x(:,seldims(1)),x(:,seldims(2)),Yt,'r*','LineWidth',2);
        hold on;
        plot3(x(:,seldims(1)),x(:,seldims(2)),y,'b.','LineWidth',2);
        if(~isempty(ci))
            plot3(x(:,seldims(1)),x(:,seldims(2)),ci(:,1),'black*','LineWidth',2);
            plot3(x(:,seldims(1)),x(:,seldims(2)),ci(:,2),'black*','LineWidth',2);
        end
        if(~isempty(Ytrue))
            plot3(x(:,seldims(1)),x(:,seldims(2)),Ytrue,'g*','LineWidth',2);
        end
        xlabel(sprintf('X_%i',seldims(1)),'FontSize',12);
        ylabel(sprintf('X_%i',seldims(2)),'FontSize',12);
        zlabel('Y','FontSize',12);
        view(3);
        hold off;    
    else
        [~,I] = sort(Yt);
        plot(Yt(I),'r-','LineWidth',2);
        hold on;
        plot(y(I),'b.','LineWidth',2);
        if(~isempty(ci))
            plot(ci(I,1),'black-','LineWidth',2);
            plot(ci(I,2),'black-','LineWidth',2);
        end
        if(~isempty(Ytrue))
            plot(Ytrue(I),'g-','LineWidth',2);
        end
        xlabel('Index','FontSize',12);
        ylabel('Y','FontSize',12);
        hold off;
    end
    grid on;
    set(gca,'FontSize',12);
end