function Problem = readproblemfile(filename,varargin)
    [fileid, message] = fopen(filename,'r');
    
    if(~isempty(message))
        error('readproblemfile:filename',message);
    end
    
    % Override certain parameters
    cellfun(@eval,varargin);
    
    while ~feof(fileid)
        line = fgetl(fileid);
        if ~isempty(line)
            if line(1) ~= '%'
                index = find(line == '=');
                override = 0;
                for i=1:length(varargin)
                    var = find(varargin{i} == '=');
                    curvar = varargin{i};
                    if(strcmp(curvar(1:var-2),line(1:index-2)))
                        override = 1;
                        Problem.(line(1:index-2)) = eval(curvar(var+2:end));
                        break;
                    end
                end
                if(~override)
                    eval(line);
                    Problem.(line(1:index-2)) = eval(line(index+2:end));
                end
            end
        end
    end
        
    fclose(fileid);
end