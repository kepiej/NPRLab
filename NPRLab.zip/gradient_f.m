function [J, f] = gradient_f(x, fun)
    % GRADIENT_F Compute Jacobian of f at x using finite differences method
    % Created by Pieter Jan Kerstens, 2010
    % f is fun evaluated at x
    % J is the gradient of fun at x
    

    % Evaluate fun in x
    f = fun(x);
    
    % Determining some constants
    t = sqrt(eps);
    n = length(x);
    m = length(f);
        
    % Compute gradient of fun at x
    J = zeros(m,n);
    p = zeros(1,n);
    for i=1:n
        p(i) = t;
        J(:,i) = (fun(x+p)-f)/t;
        p(i) = 0;
    end
end