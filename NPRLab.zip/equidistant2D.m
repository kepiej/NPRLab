function A = equidistant2D(N,varargin)
    defopt = {0,1};
    defopt(1:length(varargin)) = varargin;
    [a,b] = defopt{:};
    
    x = linspace(a,b,ceil(sqrt(N)));
    [X1, X2] = meshgrid(x,x);
    A(:,1) = reshape(X1, [], 1);
    A(:,2) = reshape(X2, [], 1);
end