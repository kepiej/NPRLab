function [ci, cputime] = saddlepointnpr(model,varargin)
%   Construct simultaneous confidence bands for a non-parametric regressor
%   model using the saddlepoint approximation
%
%   Author: Pieter Jan Kerstens, 2012
%
%   [ci, c, cputime] = SADDLEPOINTNPR(model,varargin)
%       model: model structure created by initnpr
%       varargin can contain:
%           alpha: confidence level (default: 0.05)
%           kernelft: function handle to the kernel (default: epanechnikov)
%           interp: compute saddlepoint approximation for a fraction of all
%           points and interpolate the remaining points. (default: false)
%           Ninterp: compute saddlepoint approximation in N/Ninterp points. (default: 4)
%
%       ci: upper and lower confidence bands
%       cputime: total computation time
%
%   See also: cgfK1, saddlepoint
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    if(length(varargin) > 4)
        error('saddlepointnpr:TooManyInputs','requires at most 4 optional inputs');
    end
    
    if(~strcmpi(model.smoothername(1:2),'pr'))
        error('Implementation for saddlepoint approximation only works correctly for the Priestley-Chao smoother with a 4th order kernel!');
    end

    optargs = {0.05, @epanechnikov, 0, 4};
    optargs(1:length(varargin)) = varargin;
    [alpha,kernelft,interp,Ninterp] = optargs{:};
    
    beta = 1-nthroot(1-alpha,model.nb_data); % Sidak
    
    if model.preprocess(1)=='p'
        error('Please use original data to compute confidence intervals...');
    end

    x = model.xtrain;
    y = model.ytrain;

    [Yhat, ~, g] = simnpr(model,x);
    
    tic;
    % Saddlepoint approximation
    e = Yhat-y;
    m = mean(e);
    e = e - m;
    e = e';
    
    saddlez = zeros(model.nb_data,2);
    xstart = [0 0];
    
    if(interp)
       % Interpolate (1-1/Ninterp)*nb_data data points
       sel = 1:Ninterp:model.nb_data-1;
       sel = [sel model.nb_data]; % Calculate exactly at the boundaries!
    else
        sel = 1:model.nb_data;
    end
    
    for i=sel
        [K, dK, d2K] = cgfK1(x,e,g,x(i),kernelft);
                
        try
            saddlez(i,1) = fzero(@(t) saddlepoint(K,dK,d2K,e,t,m)-(beta/2),xstart(1));
            saddlez(i,2) = fzero(@(t) saddlepoint(K,dK,d2K,e,t,m)-(1-(beta/2)),xstart(2));
        catch exception
            try
                saddlez(i,1) = fzero(@(t) saddlepoint(K,dK,d2K,e,t,m)-(beta/2),0);
                saddlez(i,2) = fzero(@(t) saddlepoint(K,dK,d2K,e,t,m)-(1-(beta/2)),0);
            catch                
                rethrow(exception);
            end
        end
        xstart = saddlez(i,:);
    end
    
    % Replace NaN values by values obtained by interpolating neighbouring
    % points
    [nani,~] = find(isnan(saddlez));
    nonani = setdiff(sel,nani);
    if(length(nonani) >= 2)
        [xnonanuni,I,~] = unique(x(nonani));
        saddleznonani = saddlez(nonani,:);
        saddlez(nani,:) = interp1(xnonanuni,saddleznonani(I,:),x(nani),[],'extrap');
%         saddlez(nani,:) = interp1(x(nonani),saddlez(nonani,:),x(nani),[],'extrap');
    end
    
    if(interp)   
        % Interpolate remaining points
        estsel = 1:model.nb_data;
        logsel = ones(size(estsel));
        logsel(sel) = 0;
        estsel = estsel(logsel > 0);
        
        [xseluni,I,~] = unique(x(sel));
        saddlezsel = saddlez(sel,:);
        saddlez(estsel,:) = interp1(xseluni,saddlezsel(I,:),x(estsel),[],'extrap');
%         saddlez(estsel,:) = interp1(x(sel),saddlez(sel,:),x(estsel),[],'extrap');
    end

    ci = [Yhat+saddlez(:,2) Yhat+saddlez(:,1)];
    
    cputime = toc;
end