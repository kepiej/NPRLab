function [newY, L, h, varargout] = averageslocal(X,Y,newX,h,varargin)
%   Local averages smoother
%
%   Implementation as described in Wasserman, "All of Nonparametric
%   statistics" chapter 5 (p.68)
%
%   Author: Pieter Jan Kerstens, 2014
%
%   [newY, L, h] = AVERAGESLOCAL(X,Y,newX,h)
%       X,Y: model data with dim(X) = [n x d] and dim(Y) = [n x 1]
%       newX: point with dim(newX) = [nX x d] to evaluate model at
%       h: (optional, default = leave-one-out cross-validation) bandwith of the kernel
%
%       newY: model evaluation at newX
%       L: L(i,:) contains the weight of each Y for newX(i). This is the
%       smoother matrix.
%       h: the used bandwith
%
%   See also NW, PRIESTLEYCHAO, LOCALPOLYFIT
%
%   Copyright (C) 2014, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    L = zeros(size(newX,1),size(X,1));
    for i=1:size(newX,1)
        % Find training points within a ball of radius h with center at
        % newX(i,:)
        ind = find(abs(X-newX(i,:)) <= h);
        nx = length(ind);
        % Take average locally
        L(i,ind) = 1./nx;
    end
    newY = L*Y;
end