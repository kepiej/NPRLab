function [ci, c, cputime, varargout] = cinpr(model,varargin)
%   Construct simultaneous confidence bands for a nonparametric regressor
%   model, assuming homoscedastic noise
%
%   Author: Pieter Jan Kerstens, 2012
%
%   [ci, c, cputime] = CINPR(model,alpha,biascorr,nrofterms)
%       model: model structure created by initnpr
%       alpha: confidence level (default = 0.05)
%       biascorr: how to account for the bias. Choose one of: 'nobiascorr','biascorr' (default) or
%       'volbiascorr'
%       nrofterms: number of terms to use for the volume-of-tube
%       approximation. Choose between 1,2 or 3 (default).
%
%       ci: upper and lower confidence bands
%       c: critical width of the tube
%       cputime: computation time
%
%   See also: voltube, prednpr
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    optargs = {0.05,'biascorr',3}; % Set default variable arguments
    optargs(1:length(varargin)) = varargin; % Replace by optionally provided arguments
    [alpha,biascorr,nrofterms] = optargs{:};
    
    if((model.x_dim > 1) && strcmpi(biascorr(1:2),'vo'))
        disp('volbiascorr currently not possible for d > 1, switching to ''biascorr''');
        biascorr = 'biascorr';
    end
    
    if model.preprocess(1)=='p'
        [x,y] = postlssvm(model,model.xtrain,model.ytrain);
    else
        x = model.xtrain; y = model.ytrain;
    end
    
    [Yhat, L, ~] = simnpr(model,x);
    
    % Estimate homoscedastic variance of residuals
    if(model.x_dim == 1)
        sigma2 = hallvar(y);
    else
        sigma2 = liitiainenvar(x,y);
    end
    
    % Calculate sigma2*||l(x)||
    s = L*diag(sigma2)*L';

    % Bias estimation by double smoothing
    if(any(strcmpi(biascorr(1:2),{'bi','vo'})))
        delta = biasestim(model,L,x,y,s);
    else
        % Do not make ci wider to account for bias
        delta = 0;
    end
    
    if(strcmpi(biascorr(1:2),'vo'))
        [z,~,cputime] = voltube(x,alpha,L,model,nrofterms,delta);
        c = z;
    else % biascorr == {nobiascorr, biascorr}
        if((nargout > 3) && (model.x_dim > 1))
            optout = cell(1,min(nargout-3,2));
            [c,~,cputime,optout{:}] = voltube(x,alpha,L,model,nrofterms);
            varargout = optout;
        else
            [c,~,cputime] = voltube(x,alpha,L,model,nrofterms);
        end
        % Bias correction
        z = c + delta;
    end
    
    ci = [Yhat+z*sqrt(diag(s)) Yhat-z*sqrt(diag(s))];
    
    if(model.x_dim == 1)
        varargout = {};
        return;
    end
    
    if(nargout >= 4)
        % Construct ci for c obtained without using the 3rd term in the formula
        c2i = [Yhat+(varargout{1}+delta)*sqrt(diag(s)) Yhat-(varargout{1}+delta)*sqrt(diag(s))];
        varargout{1} = {optout{1}, c2i};
    end
    if(nargout >= 5)
        % Construct ci for c obtained without using the 2nd and 3rd term in the formula
        c1i = [Yhat+(varargout{2}+delta)*sqrt(diag(s)) Yhat-(varargout{2}+delta)*sqrt(diag(s))];
        varargout{2} = {optout{2}, c1i};
    end
end