function [predi] = prednpr(model,Xt,varargin)
%   Construct pointwise prediction bands for a nonparametric regressor
%   model, assuming homoscedastic noise
%
%   Author: Pieter Jan Kerstens, 2013
%
%   predi = PREDNPR(model,Xt,alpha)
%       model: model structure created by initnpr
%       Xt: points of evaluation
%       alpha: confidence level
%
%       predi: upper and lower prediction bands
%
%   See also: cinpr
%
%   Copyright (C) 2013, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    optargs = {0.05}; % Set default variable arguments
    optargs(1:length(varargin)) = varargin; % Replace by optionally provided arguments
    [alpha] = optargs{:};
    
    if model.preprocess(1)=='p'
        [x,y] = postlssvm(model,model.xtrain,model.ytrain);
    else
        x = model.xtrain; y = model.ytrain;
    end
    
    % Estimate bias
    if(strcmpi(model.smoothername(1:2),'ls')) %LS-SVM
        kernel4 = 'RBF4_kernel';
    else
%         kernel4 = 'fourthorderkernel';
        kernel4 = 'rbf4';
    end

    if(isempty(model.extrarg) | (size(model.extrarg) == 1))
        modelb = initnpr(x,y,model.smoothername,'original',[],kernel4);
    else
        modelb = initnpr(x,y,model.smoothername,'original',[],kernel4,model.extrarg{2});
    end
    
    % Estimate homoscedastic variance of residuals
    if(model.x_dim == 1)
        sigma2 = hallvar(y);
    else
        sigma2 = liitiainenvar(x,y);
    end
    
    Ybhat = simnpr(modelb,x);
    z = norminv(alpha/2);
    
    [Yhat,Lpred] = simnpr(model,Xt);
    biascorr = Lpred*Ybhat - simnpr(modelb,Xt);

     % Additional variance term for prediction interval
     s = Lpred*diag(sigma2)*Lpred';

     %TODO: Check that this is correct for prediction interval!
     if(model.x_dim == 1)
        s = diag(s) + hallvar(Yhat);
     else
        s = diag(s) + liitiainenvar(real(Xt),Yhat);
     end

    % Assume normal distribution for now to reduce computational burden!
    % Use Sidak correction for (1-alfa)% simultaneous prediction bands
    predi = zeros(size(Xt,1),2);
    predi(:,1) = Yhat - biascorr + z*sqrt(s);
    predi(:,2) = Yhat - biascorr - z*sqrt(s);
end