function curver = vernpr()
%   Return current version of the NPRLab toolbox
%
%   Author: Pieter Jan Kerstens, 2015
%
%   curver = VERNPR()
%
%       curver: current version in a string
%
%   See also: updatenpr
%
%   Copyright (C) 2015, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)

    curver = '1.0.0';
end