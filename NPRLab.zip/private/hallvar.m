function sig2 = hallvar(A)
% Hall variance estimator
    n = length(A);
    sig2 = sum(((0.809.*A(1:n-2)) - (0.5.*A(2:n-1)) - (0.309.*A(3:n))).^2)./(n-2);
end