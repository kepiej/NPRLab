function delta = biasestim(model,L,x,y,s)

    if(strcmpi(model.smoothername(1:2),'ls')) %LS-SVM
        kernel4 = 'RBF4_kernel';
    else
%         kernel4 = 'fourthorderkernel';
        kernel4 = 'rbf4';
    end

    if(isempty(model.extrarg) | (size(model.extrarg) == 1))
        modelb = initnpr(x,y,model.smoothername,'original',[],kernel4);
    else
        modelb = initnpr(x,y,model.smoothername,'original',[],kernel4,model.extrarg{2});
    end
    bias = (L-eye(size(x,1)))*simnpr(modelb,x);

    delta = max(abs(bias./sqrt(diag(s))));
end