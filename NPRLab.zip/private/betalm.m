function y = betalm(l,m,x)
    y = (gamma(l+m)/(gamma(l)*gamma(m))).*(x.^(l-1)).*((1-x).^(m-1));
end