function sig2 = liitiainenvar(X,Y)
%   Multivariate variance estimator as first described in
%   Liiti�inen, Corona and Lendasse, "On Nonparametric Residual Variance
%   Estimation", Neural Processing Letters, 2008
%   and whose theoretical properties were proved in Liiti�inen, Corona and Lendasse, "Residual variance estimation
%   using a nearest neighbor statistic", Journal of Multivariate Analysis,
%   2010
%
%   Author: Pieter Jan Kerstens, 2012
%
%   function sig2 = liitiainenvar(X,Y)
%       X: n x k regressor matrix with k > 1
%       Y: n x 1 matrix
%
%       sig2: estimated variance of Y
%
%   See also: hallvar
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    assert(size(X,2) > 1,'Data has to be multidimensional! Variance estimator is not consistent for univariate data!');

    n = size(Y,1);
    Ddiag = pdist(X);
    % Essentialy equivalent to using 'squareform', but much faster!
    [r, ~] = size(X);
    D = zeros(r);
    D(tril(true(r),-1)) = Ddiag;
    D = D + D';
    D(1:n+1:n*n) = inf;
    I = zeros(n,2);
    for k=1:n
        I(k,:) = minindex(D(k,:));
    end
    sig2 = sum((Y-Y(I(:,1))).*(Y-Y(I(:,2))))/n;
end

function I = minindex(B)
    I = find(B == min(B),2);
    if(length(I) == 1)
        [~,I2] = min(setdiff(B,B(I)));
        I = [I,I2];
    end
end