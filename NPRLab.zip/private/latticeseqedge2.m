function O = latticeseqedge2(d,N,varargin)
    if(mod(N,2*d))
        % Ensure that N is divisible by (2*d)
        N = ceil(N/(2*d))*2*d;
    end

    % TODO: Not perfectly distributed over all dimensions when d is odd
    % I have not found a fix for now
    perm = randperm(N);
    perm2 = randperm(N);
    O1 = latticeseqedge(ceil(d/2),N,varargin{:});
    O2 = latticeseqedge(floor(d/2),N,varargin{:});
    O = [O1(perm,:) O2(perm2,:)];
end