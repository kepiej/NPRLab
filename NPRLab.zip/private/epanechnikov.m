function w = epanechnikov(z)
%   Epanechnikov kernel
%
%   Author: Pieter Jan Kerstens, 2011
%
%   w = EPANECHNIKOV(z)
%
%       z: value to calculate weight of
%
%       w: corresponding weight of z
%
%   See also LOCALPOLYFIT


    temp = exmin(exabs(z),ones(size(z)));
    w = 0.75.*(1-(temp.^2));
end