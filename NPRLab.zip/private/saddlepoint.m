function p = saddlepoint(K,dK,d2K,e,y,m,xstart)
%   Computes the CDF using a saddlepoint approximation
%
%   Author: Pieter Jan Kerstens, 2011
%
%   p = SADDLEPOINT(K,dK,d2K,e,y,m,xstart)
%       K: function handle to the cumulant generating function (cgf)
%       dK: function handle to cgf'
%       d2K: function handle to cgf''
%       e: residuals
%       y: Pr(Y <= y)
%       m: E[Y] (expected value of Y)
%       xstart: initial guess to solve the equation dK(x) = y (optional, default = 0)
%
%       p: the probability that Y <= y
%
%   See also: CGFK1, CGFK2
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    if(nargin < 7)
        xstart = 0;
    end
        
    n = length(e);

    p = zeros(size(y));
    for i=1:length(y)
        ty = real(fzero(@(x) dK(x)-y(i),xstart));
        wy = real(sqrt(2*n*((ty*y(i)) - K(ty))))*sign(ty);
        zy = real(ty*sqrt(n*d2K(ty)));

        if((wy ~= 0) && (zy ~= 0) && (m ~= y(i)))
            % Only valid in case y /= E[X] and zy,wy ~= 0!
            p(i) = normcdf(wy,0,1) + (normpdf(wy,0,1).*((1/wy) - (1/zy)));
        else
            [d3K, ~] = gradient_fi(0, @(x) d2K(x));
            p(i) = 0.5 + (d3K./(6.*sqrt(2*pi*n).*(d2K(0).^1.5)));
        end
    end
end