function out = seloutreturn(outsel,fun,varargin)
%   Return only a specific return value while ignoring the others
%
%   Author: Pieter Jan Kerstens, 2012
%
%   out = SELOUTRETURN(outsel,fun,varargin)
%
%       outsel: the requested return value (n = nth return value)
%       fun: the function to evaluate
%       varargin: contains all the arguments needed by fun
%
%       out: the selected outputs
    
    nout = nargout(fun);
    out = cell(1,nout);
    [out{1:outsel}] = fun(varargin{:});
    out = out{outsel};
end