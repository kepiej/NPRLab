function [newY, L, h] = priestleychao(X,Y,newX,h,varargin)
% function [newY, L, h] = priestleychao(X,Y,newX,h,varargin)
%   Priestley Chao smoother
%
%   Author: Pieter Jan Kerstens, 2011
%
%   [newY, L, h] = PRIESTLEYCHAO(X,Y,newX,h,varargin)
%       X,Y: model data
%       newX: point to evaluate model at
%       h: (optional, default = leave-one-out cross-validation) bandwith of the kernel
%       kernelft: (optional, default = biweight) kernel function
%       equidistant: equidistant design or not (optional, default = 1)
%
%       newY: model evaluation at newX
%       L: L(i,:) contains the weight of each Y for newX(i). This is the
%       smoother matrix.
%       h: the used bandwith
%
%   See also BIWEIGHT, LINEARBANDWIDTHTUNING
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)

    
    defaultopt = {@biweight,1};
    defaultopt(1:length(varargin)) = varargin;
    [kernelft,equidist] = defaultopt{:};
                
    n = size(X,1);
    nX = size(newX,1);
    
    if(~strcmp(func2str(kernelft),'biweight'))
        warning('NPRLab:private:priestleychao','You use a %s kernel instead of the default biweight kernel. Estimates might not always be correct (depending on how the X are scaled)!',func2str(kernelft));
    end
        
    if(equidist == 1)
        % Compute newX(i)-X forall i
        arg1 = (sum(newX.^2,2)*ones(1,n));
        arg2 = (sum(X.^2,2)*ones(1,nX));
        arg = arg1+arg2' - (2*X*newX')';
        arg = sqrt(arg);
        
        delta = (X(end,:)-X(1,:))./n;
        delta = sqrt(sum(delta.^2,2));
        
        L = (delta./h).*kernelft(arg./h);
    else % non equidistant design        
        % Compute newX(i)-X forall i
        arg1 = (sum(newX.^2,2)*ones(1,n-1));
        arg2 = (sum(X(2:end,:).^2,2)*ones(1,nX));
        arg = arg1+arg2' - (2*X(2:end,:)*newX')';
        arg = sqrt(arg);
        
        delta = X(2:end,:)-X(1:end-1,:);
        delta = sqrt(sum(delta.^2,2));
        delta = repmat(delta',nX,1);
        
        L = [zeros(nX,1),(delta./h).*kernelft(arg./h)];
    end
    newY = L*Y;
end