function [f,df,d2f] = cgfK1(X,e,h,xeval,weightft)
%   Cumulant generating function approximation as defined in Wang
%   'Saddlepoint methods for bootstrap confidence intervals' as K1(t)
%
%   Author: Pieter Jan Kerstens, 2011
%
%   [f,df,d2f] = cgfK1(X,e,h,x,weightft)
%       X: data points
%       e: residuals
%       h: kernel bandwith
%       xeval: point currently evaluated at
%       weightft: function handle of the kernel
%
%       f: function handle of the cumulant generating function
%       df: function handle of the first derivative of the cumulant generating function
%       d2f: function handle of the second derivative of the cumulant
%       generating function
%
%   See also: saddlepoint
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    if (nargin < 5)
       weightft = @tricube;
    end

    n = length(X);
    
    arg = (xeval-X)./h;
    w = weightft(arg)./h;
    
    function c = K1(t)
        % Cumulant generating function
        c = sum(log(sum(exp(w*e*t),2)./n))./n;
    end

    function c = dK1(t)
        temp = exp(w*e*t);
        sumeii = sum(temp,2);
        c = sum(sum((w*e).*temp,2)./sumeii)./n;
    end

    function c = d2K1(t)
        temp = exp(w*e*t);
        sumeii = sum(temp,2);
        c = sum((sum(((w*e).^2).*temp,2)./sumeii) - ((sum((w*e).*temp,2).^2)./(sumeii.^2)))./n;
    end

    f = @K1;
    df = @dK1;
    d2f = @d2K1;
end