function A = vandercutoff(v,p)
%   Construct the Vandermonde matrix whose columns
%   are powers of the vector V up to power p, that is A(i,j) = v(i)^(j-1).
%   This is a small modification of MATLAB built-in function vander.
%
%   Author: Pieter Jan Kerstens, 2012
%
%   A = VANDERCUTOFF(v,p)
%       v: a vector
%       p: columns are powers of the vector v up to and including power p
%
%       A: the Vandermonde matrix up to the power p instead of the length
%       of the vector v. size(A) = [n,p+1] with n the length of v.
%
%   See also: vander


n = length(v);
v = v(:);
A = ones(n,p+1);
for j=2:p+1
    A(:,j) = v.*A(:,j-1);
end
