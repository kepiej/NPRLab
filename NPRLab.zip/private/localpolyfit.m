function [newY, L, h, varargout] = localpolyfit(X,Y,newX,h,varargin)
%   Local polynomial fitting with polynomials of degree p
%
%   Implementation as described in
%		Wasserman, "All of Nonparametric statistics", chapter 5 (p.76)
%		or
%		Fan & Gijbels, "Local Polynomial Modelling and its applications", chapter 3 (p.71)
%
%   Author: Pieter Jan Kerstens, 2011
%
%   [newY, L, h] = LOCALPOLYFIT(X,Y,newX,h,varargin)
%       X,Y: model data
%       newX: point to evaluate model at
%       h: (optional, default = leave-one-out cross-validation) bandwidth of the kernel
%       varargin can contain:
%          kernelft: (optional, default = epanechnikov) function handle to the kernel to be used
%          p: (optional, default = 1) degree of the local polynomial. Use
%          NW if p = 0 for efficiency!
%
%       newY: model evaluation at newX
%       L: L(i,:) contains the weight of each Y for newX(i). This is the
%       smoother matrix.
%       h: the used bandwidth
%
%   See also EPANECHNIKOV, LINEARBANDWIDTHTUNING, NW
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)

    
%     defaultopt = {@epanechnikov,1};
    defaultopt = {@rbf,1};
    defaultopt(1:length(varargin)) = varargin;
    [kernelft,p] = defaultopt{:};
     
    nX = size(newX,1);
    n = size(X,1);
    d = size(X,2);
    newY = zeros(nX,1);
    newdY = zeros(nX,d);
    L = zeros(nX,n);

    % Compute newX(i)-X forall i
    arg1 = (sum(newX.^2,2)*ones(1,n));
    arg2 = (sum(X.^2,2)*ones(1,nX));
    arg = arg1+arg2' - (2*X*newX')';
    arg = sqrt(arg);
        
    if((p == 1) && (d == 1)) % Efficient implementation as found in Wasserman
        for i=1:nX
            xidiff = X-newX(i,:);
            kerneleval = kernelft(arg(i,:)./h)./h;
            sn1 = kerneleval*xidiff;
            sn2 = kerneleval*(xidiff.^2);
            L(i,:) = kerneleval.*(sn2 - (xidiff*sn1))';
        end
        L = bsxfun(@rdivide, L, sum(L,2));
        newY = L*Y;
    else
        for i=1:nX
            % FIXME: only correct for 1D data or d > 1 data with p=1!
            % FIXME: Generate cross terms of the polynomial expansion!
            Xm = vandercutoff(X(:,1)-newX(i,1),p);
            for j=2:d
                temp = vandercutoff(X(:,j)-newX(i,j),p);
                Xm = [Xm, temp(:,2:end)];
            end
            
            W = diag(kernelft(arg(i,:)./h)./(h.^d));

            % Compute LS solution
            S = Xm'*W*Xm;
            % If [p,d] == [2,1] or [p,d] == [1,2] then size(S) is 3x3
            if(size(S,2) == 3)
                % Analytic inversion of S matrix
                detS = S(1,1)*((S(2,2)*S(3,3))-(S(2,3)*S(3,2))) - S(1,2)*((S(3,3)*S(2,1))-(S(2,3)*S(3,1))) + S(1,3)*((S(2,1)*S(3,2))-(S(2,2)*S(3,1)));
                invS = [(S(2,2)*S(3,3))-(S(2,3)*S(3,2)), -((S(1,2)*S(3,3))-(S(1,3)*S(3,2))), (S(1,2)*S(2,3))-(S(1,3)*S(2,2));
                 -((S(2,1)*S(3,3))-(S(2,3)*S(3,1))), (S(1,1)*S(3,3))-(S(1,3)*S(3,1)), -((S(1,1)*S(2,3))-(S(1,3)*S(2,1)));
                 (S(2,1)*S(3,2))-(S(2,2)*S(3,1)), -((S(1,1)*S(3,2))-(S(1,2)*S(3,1))), (S(1,1)*S(2,2))-(S(1,2)*S(2,1))
                    ]./detS;
                beta = invS*(Xm'*W);
            else
                rcondnum = rcond(S);
                if(isinf(rcondnum)) % Exact inversion impossible
                    beta = pinv(S)*(Xm'*W);
                elseif rcondnum < 1e-1 % Inversion result are likely to be inaccurate
                    S = S + 1e-3.*eye(size(S));
                    beta = S\(Xm'*W);
                else
                    beta = S\(Xm'*W);
                end
            end
            
            % Evaluate polynomial at newX(i)
            newY(i) = beta(1,:)*Y;
            
            if(nargout > 3)
                % First derivative if requested by user
                for j=1:d
                    newdY(i,j) = beta(j+1,:)*Y;
                end
            end

            % Update smoother matrix
            L(i,:) = beta(1,:);
        end
    end

    if(nargout > 3)
        varargout = {newdY};
    end
end