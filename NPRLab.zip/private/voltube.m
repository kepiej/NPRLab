function [c, consts, cputime, varargout] = voltube(X,alpha,L,model,nrofterms,delta)
%   Computes the width c of the confidence bands using the volume-of-tube
%   formula by Sun, J. and Loader, C. R. (1994)
%
%   Author: Pieter Jan Kerstens, 2012
%
%   [c, consts, cputime] = VOLTUBE(X,alpha,L,smoother)
%
%       X: trainingsdata
%       alpha: confidence level
%       L: smoother matrix
%       model: model structure obtained by initnpr
%       nrofterms: number of terms to use for the volume-of-tube
%       approximation; choose between 1,2 or 3.
%       delta: max(abs(b(x))/Var[m_n(x)])
%       
%       c: confidence bands width
%       consts: cell containing the calculated constants
%       kappa0, kappa2, xsi0, xsi1 and m0
%       cputime: computation time
%
%   See also: gradient_fi, cinpr
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)

    tic;

    smoother = model.smoother;
    d = model.x_dim;
    n = model.nb_data;

    opt = optimset('Display','off','TolX',1e-15);
    if((d == 1))
        v = n - real(trace(L));
        k0 = quadgk(@(x) dsmootherm1(smoother,x),min(X),max(X));
        
        if(nargin < 6)
            tube = @(x) ((k0/pi)*(1+(x.^2/v))^(-v/2))+(1-tcdf(x,v))-alpha;
        else % Sun & Loader correction
            tube = @(x) (k0/(2*pi))*((1-chi2cdf((x-delta)^2,2))+(1-chi2cdf((x+delta)^2,2)))-alpha;
        end
        
        c = fsolve(tube,3,opt);
        consts = {k0, 2};
        cputime = toc;
    else % multidimensional
        e = 256; % Number of integration points, error rate is approx. 1/N

        % Ensure that N is divisible by (2*d)
        e = ceil(e/(2*d))*2*d;
        
        % Check if a worker pool is open and, if not, open one
        isOpen = matlabpool('size') > 0;
        if(~isOpen)
            matlabpool open;
        end

        % Parallel calculation of constants
        consfunc = {@kappa,@zeta};
        consts = cell(1,2);
        parfor i=1:2
            consts{i} = consfunc{i}(X,smoother,d,e,nrofterms);
        end
        
        [k0, k2] = deal(consts{1}{:});
        [zeta0, zeta1, m0] = deal(consts{2}{:});
                
        if(~isOpen)
            matlabpool close;
        end

        W = (eye(n)-L')*(eye(n)-L); % See book Loader
        df = (trace(W))^2/trace(W^2); % See book Loader (p.161)
        tube = @(x) k0*(gamma((d+1)/2)./pi^((d+1)/2)).*(1-fcdf(x.^2/(d+1),d+1,df))+(zeta0/2).*(gamma(d/2)./pi^(d/2)).*(1-fcdf(x.^2/d,d,df))+((k2+zeta1+m0)/(2*pi)).*(gamma((d-1)/2)./pi^((d-1)/2)).*(1-fcdf(x.^2/(d-1),d-1,df))-alpha;
        c = fzero(tube,3,opt);
        
        cputime = toc;
        
        if(nargout >= 4)
            % Don't use 3rd term in formula
            tube = @(x) k0*(gamma((d+1)/2)./pi^((d+1)/2)).*(1-fcdf(x.^2/(d+1),d+1,df))+(zeta0/2).*(gamma(d/2)./pi^(d/2)).*(1-fcdf(x.^2/d,d,df))-alpha;
            varargout{1} = fzero(tube,3,opt);
        end
        if(nargout >= 5)
            % Don't use 2nd term in formula
            tube = @(x) k0*(gamma((d+1)/2)./pi^((d+1)/2)).*(1-fcdf(x.^2/(d+1),d+1,df))-alpha;
            varargout{2} = fzero(tube,3,opt);
        end
    end
end

% Compute T(x) = L./norm(L)
function T = smootherm(smoother,x)
    [~,newL,~] = smoother(x);
    T = newL./norm(newL);
end

% Compute norm(dT) for 1D case
function dT = dsmootherm1(smoother,x)
    dT = arrayfun(@(t) norm(gradient_fi(t,@(u) smootherm(smoother,u))),x);
end

% ---- Computation of constants for multidimensional case ----

% Compute kappa_0 and kappa_2 constants
function kappaconsts = kappa(X,smoother,d,e,nrofterms)
    T = @(u) smootherm(smoother,u);
    dT = @(t) gradient_fi(t,T);

    latticeseq_b2 init0
    latticeseq_b2(d, e);
    O = latticeseq_b2(d, e)';
    [O,dom] = scale(O,X);
    I = [0 0];
    fail = 0;
    for i=1:e
        % Compute kappa_0
        A = dT(O(i,:));
        detAA = sqrt(det(A'*A));
        I(1) = I(1) + detAA;

        if(nrofterms == 3)
            % Compute kappa_2
            S = 0;
            dA = hessiancsd(T,O(i,:));
            AA = pinv(A'*A);
            try
                for j=2:d
                    for k=1:j-1        
                        S = S + ((bkj(d,j,j,A,dA,AA)*bkj(d,k,k,A,dA,AA)') - (bkj(d,j,k,A,dA,AA)*bkj(d,k,j,A,dA,AA)'));
                    end
                end
            catch
                fail = fail + 1;
                continue;
            end
            I(2) = I(2) + ((S - (d*(d-1)/2))*detAA);
        end
    end
    k0 = I(1)*dom/e;
    k2 = I(2)*dom/(e-fail);
    
    kappaconsts = {real(k0) real(k2)};
end

% Compute zeta_0, zeta_1 and m0 constants
function zetaconsts = zeta(X,smoother,d,e,nrofterms)
    if(nrofterms < 2)
        % Nothing to compute for the 1-term approximation
        zetaconsts = {0,0,0};
        return;
    end

    T = @(u) smootherm(smoother,u);
    dT = @(t) gradient_fi(t,T);

    latticeseq_b2 init0
    latticeseq_b2(d, e);
    % Points on dX
    O = latticeseqedge(d,e);
    [O,dom] = scale(O,X);
    % Points on d2X
    Om = latticeseqedge2(d,e);
    [Om,domm] = scale(Om,X);
    
    I = [0 0 0];
    fail = 0;
    Id = eye(size(X,1));
    
    % O numbers are scaled to the domain of X
    % min(X) corresponds to 0, max(X) to 1
    minOv = min(X);
    maxOv = max(X);
    for i=1:e
        k = find(abs(O(i,:)-minOv) < 1e-14 | abs(O(i,:)-maxOv) < 1e-14,1);
        
        % Compute zeta0
        A = dT(O(i,:));
        Astar = A(:,[1:k-1,k+1:d]);
        detAAstar = sqrt(det(Astar'*Astar));
        I(1) = I(1) + detAAstar;
        
        if(nrofterms == 3)
            % Compute zeta1
            % What about: "with similar definitions for zeta1(x) on other faces"?
            % Is this correct?
            AsAs = pinv(Astar'*Astar);
            dAstar = hessiancsd(T,O(i,:));
            Ux = (Id - (Astar*AsAs*Astar'))*A(:,k);
            Ux = Ux./norm(Ux);
            ej = zeros(1,d-1);
            zeta1x = 0;
            for j=1:d-1
                ej(j) = 1;
                dAj = cell2mat(dAstar(j,[1:k-1,k+1:end]));
                dAj = reshape(dAj,d-1,length(dAj)/(d-1));
                zeta1x = zeta1x + ej*AsAs*dAj*Ux;
                ej(j) = 0;
            end
            I(2) = I(2) + (-zeta1x)*detAAstar;
        
            k = find(abs(Om(i,:)-maxOv) < 1e-14 | abs(Om(i,:)-minOv) < 1e-14,2);

            % Compute m0
            % What about: "define m0(x) similarly in regions where other pairs
            % of faces meet"?
            % Is this correct?
            A = dT(Om(i,:));
            Astarstar = A(:,setdiff(1:d,k));
            detAAstarstar = sqrt(det(Astarstar'*Astarstar));

            Astar = A(:,setdiff(1:d,k(1)));
            Ux = (Id - Astar*pinv(Astar'*Astar)*Astar')*A(:,k(1));
            Ux = Ux./norm(Ux);

            Astar = A(:,setdiff(1:d,k(2)));
            Ux1 = (Id - Astar*pinv(Astar'*Astar)*Astar')*A(:,k(2));
            Ux1 = Ux1./norm(Ux1);

            m0x = acos(Ux1'*Ux);        
            I(3) = I(3) + (m0x*detAAstarstar);
        end
    end
    zeta0 = I(1)*dom/e;
    zeta1 = I(2)*dom/(e-fail);
    m0 = I(3)*domm/(e-fail);

    zetaconsts = {real(zeta0) real(zeta1) real(m0)};
end

function bkj = bkj(d,k,j,A,dA,AA)
    dAj = reshape(cell2mat(dA(j,:)),d,length(cell2mat(dA(j,:)))/d);
    ek = zeros(1,d);
    ek(k) = 1;
    bkj = ek*AA*dAj*(eye(size(A,1))-(A*AA*A'));
end

% Copied from LS-SVMLab
% Scale numbers to the range of training data
function [O,dom] = scale(O,x)
    mi = min(x);
    ma = max(x);
    dom = prod(ma-mi);
    for i=1:length(mi)
        O(:,i) = mi(i) + (ma(i)-mi(i))*O(:,i);
    end
end