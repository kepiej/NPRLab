function umin = exmin(u1,u2)

% function exmin(u1,u2)
% analytic extension of real min function
% Author: Prof. Mike Giles
% Source: http://people.maths.ox.ac.uk/gilesm/matlab_tips/exmin.m

sw   = real(u1) < real(u2);
umin = sw.*u1 + (1-sw).*u2;
