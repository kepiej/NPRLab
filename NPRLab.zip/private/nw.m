function [newY, L, h] = nw(X,Y,newX,h,varargin)
%   Nadaraya-Watson smoother
%
%   Implementation as described in Wasserman, "All of Nonparametric
%   statistics" chapter 5 (p.71)
%
%   Author: Pieter Jan Kerstens, 2012
%
%   [newY, L, h] = NW(X,Y,newX,h,kernelft)
%       X,Y: model data with dim(X) = [n x d] and dim(Y) = [n x 1]
%       newX: point with dim(newX) = [nX x d] to evaluate model at
%       h: (optional, default = leave-one-out cross-validation) bandwith of the kernel
%       kernelft: (optional, default = tricube) kernel function
%
%       newY: model evaluation at newX
%       L: L(i,:) contains the weight of each Y for newX(i). This is the
%       smoother matrix.
%       h: the used bandwith
%
%   See also EPANECHNIKOV, RBF, TRICUBE, LINEARBANDWIDTHTUNING
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


    nX = size(newX,1);
    n = size(X,1);

%     defaultopt = {@epanechnikov};
    defaultopt = {@rbf};
    defaultopt(1:length(varargin)) = varargin;
    kernelft = defaultopt{:};
            
    % Compute newX(i)-X forall i
    arg1 = (sum(newX.^2,2)*ones(1,n));
    arg2 = (sum(X.^2,2)*ones(1,nX));    
    arg = arg1+arg2' - (2*X*newX')';
    arg = sqrt(arg);
    
    L = kernelft(arg./h);

    L = bsxfun(@rdivide, L, sum(L,2));
    newY = L*Y;
end