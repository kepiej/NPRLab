function w = rbf4(z)
    w = 0.5.*((2*pi)^(-1/2)).*(3-(z.^2)).*exp(-(z.^2)./2);
end