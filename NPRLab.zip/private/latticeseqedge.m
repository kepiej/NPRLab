function O = latticeseqedge(d,N,varargin)
    
    if(mod(N,2*d))
        % Ensure that N is divisible by (2*d)
        N = ceil(N/(2*d))*2*d;
    end

    defopt = {@latticeseq_b2};
    defopt(1:length(varargin)) = varargin;
    func = defopt{:};
    
    O = func(d,N)';
    
    % Modify lattice points so that each dimension has N/d boundary points
    for i=1:d
        ind = ((i-1)*(N/d) + 1):((i-1)*(N/d) + N/d);
        O(ind,i) = repmat([0;1],N/(2*d),1);
    end
end