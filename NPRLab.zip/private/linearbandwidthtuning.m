function optimh = linearbandwidthtuning(Y,fun,scorefun,starth)
%   Leave-one-out or generalized cross-validation optimization of the bandwith h of a linear
%   smoother
%
%   Implementation as described in Wasserman, "All of Nonparametric
%   statistics" chapter 5
%
%   Author: Pieter Jan Kerstens, 2011-2012
%
%   optimh = LINEARBANDWIDTHTUNING(Y,fun,starth,scorefun)
%       Y: the model output values
%       fun: function handle to the linear smoother
%       starth: initial guess (optional)
%       scorefun: leave-one-out ('lcv'), generalized cross-validation
%       ('gcv') or AICC ('aic') (optional: default = 'lcv')
%
%       optimh: the optimal bandwith for the linear smoother
%
%   See also: csa, fminsearch
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)

    
    % Leave-one-out cross-validation score function
    function score = leaveoneoutscorefun(h)
        score = zeros(1,length(h));
        for i=1:length(h)
            [yy, L, ~] = fun(exp(h(i)));
            score(i) = sum(((Y-yy)./(1-diag(L))).^2);
        end
    end

    % Generalized cross-validation score function
    function score = gcvscorefun(h)
        score = zeros(1,length(h));
        for i=1:length(h)
            [yy, L, ~] = fun(exp(h(i)));
            v = trace(L);
            nyy = length(yy);
            score(i) = sum(((Y-yy)./(1-(v/nyy))).^2);
        end
    end

    % Akaike Information Criterium Corrected (AICC) score function
    % See Hurvich et al. (1998)
    function score = aiccscorefun(h)
        score = zeros(1,length(h));
        for i=1:length(h)
            [yy, L, ~] = fun(exp(h(i)));
            nyy = length(yy);
            v = trace(L);
            score(i) = log(sum((Y-yy).^2)/nyy) + 1 + (2*(v+1)/(nyy-v-2));
        end
    end

    if(nargin < 3 || isempty(scorefun))
        scorefun = @leaveoneoutscorefun;
%         scorefun = @gcvscorefun;
%         scorefun = @aiccscorefun;
    else
        costfuns = containers.Map({'lcv', 'gcv', 'aicc'},{@leaveoneoutscorefun,@gcvscorefun,@aiccscorefun});
        try
            scorefun = costfuns(lower(scorefun(1:3)));
        catch
            error('linearbandwidthtuning:unknown score function!');
        end
    end
    
    warning('off','MATLAB:singularMatrix');
    warning('off','MATLAB:nearlySingularMatrix');
    
    if(nargin < 4 || isempty(starth))
        % Generate random points uniformly in [0.0498, 1.6275e+005] and
          % select 5 based on the quantiles. This ensures that our
          % startpoints are not too much near each other.
          starth = quantile(-3 + 15.*rand(1,300),[0.001 0.05 0.5 0.995 0.999]);
          % Use CSA to find good starting point
          [starth,estarth] = csa(starth,scorefun);
    else
        estarth = 1;
    end
       
    % Optimise starting at starth using a simplex algorithm
    if(estarth ~= 0)
        [optimh,~,exitflag] = fminsearch(scorefun,starth);
        optimh = exp(optimh);
    
        if(exitflag < 1)
            warning('linearbandwidthtuning:NoMinimum','No minimum h found!');
        end
    else % starth is already the optimal bandwidth
        optimh = exp(starth);
    end
    
    warning('on','MATLAB:singularMatrix');
    warning('on','MATLAB:nearlySingularMatrix');
end