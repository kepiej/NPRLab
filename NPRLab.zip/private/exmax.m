function umax = exmax(u1,u2)

% function exmax(u1,u2)
% analytic extension of real max function
% Author: Prof. Mike Giles
% Source: http://people.maths.ox.ac.uk/gilesm/matlab_tips/exmax.m

sw   = real(u1) > real(u2);
umax = sw.*u1 + (1-sw).*u2;
