function [f,df,d2f] = cgfK2(X,e,xeval,weightft)
% cgfK2(X,e,xeval,weightft)
%
% Cumulant generating function approximation as defined in Wang
% 'Saddlepoint methods for bootstrap confidence intervals' as K2(t)
%
% Author: Pieter Jan Kerstens, 2011
%
%
%   X: x data points
%   e: residuals
%   xeval:  point of evaluation
%   weightft: function handle to the weight function (aka Kernel)
%   (optional, default = tricube)
%
%   Copyright (C) 2012, Pieter Jan Kerstens
%   Distributed under the GNU GPL version 3 license (see included license in COPYING file)


   if (nargin < 4)
       weightft = @tricube;
   end

   k1 = 0;
   n = length(X);

   arg = (xeval-X)./n;     %  distances from this new point to data
   w = weightft(arg)./n;  %  weight function for x distance
   
   k2 = sum(w.^2,2)./(n.^2);
   k3 = sum(w.^3,2)./(n.^3);
   k4 = sum(w.^4,2)./(n.^4);

   k2 = k2.*(sum(e.^2,2)./n);
   k3 = k3.*(sum(e.^3,2)./n);
   k4 = k4.*((sum(e.^4,2)./n) - 3.*(sum(e.^2,2)./n).^2);
   
   b2 = 8; % As suggested by Wang
   
    function d = damping(t)
        d = exp(-(t.^2)./(n.*k3.*b2));
    end

    function dd = ddamping(t)
        dd = ((-2.*t)./(n.*k3.*b2)).*exp(-(t.^2)./(n.*k3.*b2));
    end

    function d2d = d2damping(t)
        d2d = (-2./(n.*k3.*b2)).*exp(-(t.^2)./(n.*k3.*b2)) + (4.*(t.^2)./((n.^2).*(k3.^2).*(b2.^2))).*exp(-(t.^2)./(n.*k3.*b2));
    end

    function c = K2(t)
       c = (k1.*t) + (0.5.*n.*k2.*(t.^2)) + (((n.^2).*k3.*(t.^3)./6) + ((n.^3).*k4.*(t.^4)./24)).*damping(t);
    end

    function dc = dK2(t)
       dc = k1 + (n.*k2.*t) + ((0.5.*(n.^2).*k3.*(t.^2)) + (((n.^3).*k4.*(t.^3))./6)).*damping(t) + ((((n.^2).*k3.*(t.^3))./6) + (((n.^3).*k4.*(t.^4))./24)).*ddamping(t);
    end

    function d2c = d2K2(t)
       d2c = (n.*k2) + (((n.^2).*k3.*t) + ((n.^3).*k4.*(t.^2)./2)).*damping(t) + 2.*(((n.^2).*k3.*(t.^2)./2) + ((n.^3).*k4.*(t.^3)./6)).*ddamping(t) + (((n.^2).*k3.*(t.^3)./6) + ((n.^3).*k4.*(t.^4)./24)).*d2damping(t);
    end

    f = @K2;
    df = @dK2;
    d2f = @d2K2;
end