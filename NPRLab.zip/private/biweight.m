function w = biweight(t)
    z = exmin(exabs(t),ones(size(t)));
    w = (15/16).*(1-(z.^2)).^2;
end