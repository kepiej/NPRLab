function [J, f] = gradient_fi(x, fun)
% GRADIENT_FI Compute Jacobian of f at x using the imaginary trick method
    % Created by Pieter Jan Kerstens, 2010
    % J is the gradient of fun at x
    % f is fun evaluated at x
    
    % Evaluate fun in x
    f = fun(x);
    
    % Determining some constants
%     t = eps;
    t = 10^-100;
    m = length(f);
    n = length(x);
    
    % Compute gradient of fun at x
    J = zeros(m,n);
    for k=1:n
        p = x;
        p(k) = p(k) + t*1i;
        J(:,k) = imag(fun(p))/t;
    end
end