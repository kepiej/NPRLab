function uabs = exabs(u)

% function exabs(u)
% analytic extension of real abs function
% Author: Prof. Mike Giles
% Source: http://people.maths.ox.ac.uk/gilesm/matlab_tips/exabs.m

uabs = sign(real(u)) .* u;
