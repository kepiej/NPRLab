function S = smootherlssvmmod(model,Xt,varargin)

% Calculates the smoother matrix for LS-SVM.
% Inputs:
%        - model : object oriented interface of the FS-LSSVM model
%        - Xt (*): smoother matrix evaluated in test point(s) Xt
%
% Outputs:
%        - S: smoother matrix

% Copyright (c) 2011,  KULeuven-ESAT-SCD, License & help @ http://www.esat.kuleuven.be/sista/lssvmlab

% This is a modified version of 'smootherlssvm'. The only difference is
% that in-between calls the matrices K,Z,c,J are reused instead of recalculated!

if isempty(model.gam) && isempty(model.kernel_pars)
    error('Please supply one or more learning parameters');
end

if(nargin < 3)
    K = kernel_matrix(model.xtrain,model.kernel_type,model.kernel_pars);
    Z = pinv(K+eye(model.nb_data)./model.gam);
    c = sum(sum(Z));
    J = ones(model.nb_data)./c;
else
    [K,Z,c,J] = varargin{:};
end

if nargin < 2
    S = K*(Z-Z*J*Z) + J*Z;
else
    if model.preprocess(1)=='p'
        % Preprocess the test data
        Xt = prelssvm(model,Xt);
    end
    Kt = kernel_matrix(model.xtrain,model.kernel_type,model.kernel_pars,Xt)';
    J1 = ones(size(Kt,1),size(Z,1))./c;
    S = Kt*(Z-Z*J*Z) + J1*Z;
end