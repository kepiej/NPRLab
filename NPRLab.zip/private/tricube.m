function res = tricube(x)    
    z = exmin(exabs(x),ones(size(x)));
    res = (70/81).*(1-(exabs(z).^3)).^3;
end