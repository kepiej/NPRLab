function w = fourthorderkernel(t,kernel)
    if((nargin < 2) || isempty(kernel))
        kernel = @epanechnikov;
    end
    c = 0.670854;
    
    w = (kernel(t) - (c^3)*kernel(c*t))/(1-(c^2));
end