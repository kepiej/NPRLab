function w = rbf(z)
    w = exp(-(z.^2));
end