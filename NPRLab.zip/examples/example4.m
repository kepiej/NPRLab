%

disp('This example demonstrates: fitting, computing simultaneous confidence bands and plotting data by a smoother.');

% Create data
N = 225;
X = equidistant2D(N,-1,1);
Ytrue = mvnpdf(X,0,[0.25 0.25]);
Y = Ytrue + 0.3*randn(ceil(sqrt(N))^2,1);

% Initialize and train a LS-SVM model
model = initnpr(X,Y,'LS-SVM');

% Compute 100*(1-alpha)% confidence bands by volume-of-tube approximation
ci = cinpr(model);

% Plot the trained model together with the true underlying function and
% confidence bands
plotnpr(model, ci);
hold on;
[X1, X2] = meshgrid(X(:,1),X(:,2));
SurfaceF = TriScatteredInterp(X,Ytrue);
Z = SurfaceF(X1,X2);
surf(X(:,1),X(:,2),Z);
shading interp;
view(3);

% Clean-up variables
clear N X Y Ytrue model ci SurfaceF X1 X2 Z;