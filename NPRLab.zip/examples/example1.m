%

disp('This example demonstrates the most basic use of NPRLab: fitting and plotting data by a simple smoother.');

% Read data and assign it to variables for ease of use
problem = readproblemfile('problemfile1.m');
X = problem.X;
Ytrue = problem.TrueFt;
Y = Ytrue + problem.Noise;

% Initialize and train a Nadaraya-Watson model
model = initnpr(X,Y,'nadaraya watson','original');

% Plot the trained model together with the true underlying function
plotnpr(model,[],Ytrue);

% Clean-up variables
clear problem X Ytrue Y model;