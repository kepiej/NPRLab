%

disp('This example demonstrates: fitting, computing simultaneous confidence bands and plotting data by a smoother.');

% Read data and assign it to variables for ease of use
problem = readproblemfile('problemfile5.m');
X = problem.X;
Ytrue = problem.TrueFt;
Y = Ytrue + problem.Noise;
alpha = problem.alpha;

% Initialize and train a Nadaraya-Watson model
model = initnpr(X,Y,'nadaraya watson');

% Compute 100*(1-alpha)% confidence bands by volume-of-tube approximation
ci = cinpr(model,alpha);

% Plot the trained model together with the true underlying function and
% confidence bands
plotnpr(model,ci,Ytrue);

% Clean-up variables
clear problem X Ytrue Y model ci alpha;